import React from 'react';
import InstagramFeed from "./instagram-feed/InstagramFeed";

export default function App() {
  return <InstagramFeed />;
}